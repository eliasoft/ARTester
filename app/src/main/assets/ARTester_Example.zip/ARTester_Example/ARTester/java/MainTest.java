import eliasoft.artester.*;
// If you want to get a documentation about the "eliasoft.artester" package, you can visit: https://gitlab.com/eliasoft/artester/-/blob/main/artester-api-reference.md

public class MainTest{

	public MainTest(TestActivity ta) throws Throwable{
		// This constructor is called when TestActivity.onCreate(Bundle) method runs.
		// The TestActivity will restart and print the stack trace every time an uncaught exception is thrown, so as long as the code is executed only by ARTester, you may not need to catch exceptions yourself. What's more. If you need to catch an exception inside a method that is overriding from another class or interface method, you can use: try{ ... }catch(Exception ex){ex.printStackTrace();}
		System.out.print("Hello World!");
		
	}

	public boolean onBackPressed(){
		// This method is called when TestActivity.onBackPressed() method runs.
		// This method is optional, and you can remove it, wich will be equivalent to returning true.
		// If this method returns true, means you want to let the activity do what it's supposed to do. otherwise, you must define the behavior you want.
		return true;
	}

}